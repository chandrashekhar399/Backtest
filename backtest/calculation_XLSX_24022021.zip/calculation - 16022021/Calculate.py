import calculation.Functions_db as f
import pyodbc as ms
import calculation.Functions_Calculate as f_c
from itertools import chain
import datetime

def Cal_Index(D_Index,D_Data,D_ISIN,D_Date,D_RIC_ISIN,last_Period,cursor1):
    Index_List = list()
    print(datetime.datetime.now()) 
    Constituents_List = list()
    D_Index["M_Cap_PR"],D_Index["M_Cap_TR"],D_Index["M_Cap_NTR"]=D_Index["MV"],D_Index["MV"],D_Index["MV"]
    D_Index["Index_Value_PR"], D_Index["Index_Value_TR"],D_Index["Index_Value_NTR"]= D_Index["IV"],D_Index["IV"],D_Index["IV"]
    Divisor = D_Index["MV"]/D_Index["IV"]
    D_Index["Divisor_PR"], D_Index["Divisor_TR"],D_Index["Divisor_NTR"]=Divisor,Divisor,Divisor
    j=0
    #for period in D_Data:
    for period in D_Data:

        #D_Values= {}
        Index_Currency = D_Index["Currency"]
        format_str = '%m-%d-%Y'
        S_Date = datetime.datetime.strptime(D_Date[period+"_START"], format_str).date()- datetime.timedelta(days=0)
        print(S_Date.weekday())
        if S_Date.weekday()==5:
            S_Date = S_Date - datetime.timedelta(days=1)
        elif S_Date.weekday()==6:
            S_Date = S_Date - datetime.timedelta(days=2)
            
        S_Date_Minus_Five = datetime.datetime.strptime(D_Date[period+"_START"], format_str).date()- datetime.timedelta(days=5)
        E_Date = datetime.datetime.strptime(D_Date[period+"_END"], format_str).date()- datetime.timedelta(days=0)
       
        i=0
        
        D_Price,D_LastDate,currency_list,D_ISIN_Currency = f.Get_PRICE(cursor1,D_ISIN[period],S_Date_Minus_Five.strftime("%x"),E_Date.strftime("%x"),D_Index["Identifier"])
        #f.Set_TR_Price(D_Date,D_RIC_ISIN,last_Period,D_Price)
        currency_list.append(Index_Currency)
        Ex_Rate = f.Get_Currency(cursor1,currency_list,S_Date_Minus_Five.strftime("%x"),E_Date.strftime("%x"))
        Tax_Rate = f.Get_TAX(cursor1)
        D_CA = f.Get_CA(cursor1,D_ISIN[period],S_Date.strftime("%x"),E_Date.strftime("%x"),D_Index["Identifier"])
            
        Latest_Price={}
        Latest_Ex_Rate={}

        while S_Date_Minus_Five <= E_Date:
            f_c.Set_Latest_Ex_Rate(Index_Currency,D_Data[period],Ex_Rate,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),D_ISIN_Currency)
            f_c.Set_Latest_Price(D_Data[period],D_Price,Latest_Price,S_Date_Minus_Five.strftime("%x"))
            if S_Date_Minus_Five>=S_Date:
                print_flag = GetFlag(D_Index["DCFO"],S_Date_Minus_Five.strftime("%x"),D_Date[period+'_END'])
                if i==0:                    
                    #print('Cal Shares for Period '+period)
                    f_c.Cal_Shares(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Constituents_List,period,Tax_Rate,D_ISIN_Currency,print_flag,j)
                else:#if j!=0:                    
                    M_Cap = f_c.Cal_Index_Close(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Constituents_List,period,Tax_Rate,D_ISIN_Currency,print_flag)
                f_c.Fill_Index_Report_Data(D_Index,Index_List,period,S_Date_Minus_Five)
                i += 1
                j += 1
                
            if S_Date_Minus_Five.weekday()==4:
                S_Date_Minus_Five = S_Date_Minus_Five + datetime.timedelta(days=3)
            else:
                S_Date_Minus_Five = S_Date_Minus_Five + datetime.timedelta(days=1)

            if S_Date_Minus_Five>S_Date and i!=0 and S_Date_Minus_Five <= E_Date:
                f_c.Delist(D_Data[period],S_Date_Minus_Five.strftime("%x"),D_LastDate,E_Date.strftime("%x"))
                f_c.Cal_Index_Open(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Tax_Rate,D_ISIN_Currency,Ex_Rate,D_CA)
        
    print(datetime.datetime.now())                  
    files = f_c.Print_Reports(Index_List,Constituents_List)
    return files


def getList(dict): 
    list1 = [] 
    for key in dict.keys(): 
        list1.append(key)      
    return list1

def GetFlag(option,date,date_end):
    if option =="ND":
        return 0
    elif option =="CD":
        return 1
    elif option =="EDD":
        format_str = '%m-%d-%Y'
        endDate = datetime.datetime.strptime(date_end, format_str).date()
        if endDate.strftime("%x") ==date:
            return 1
        else :
            return 0
