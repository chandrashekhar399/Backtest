import pyodbc
import csv
from itertools import chain
import random
import datetime

def Print_Reports(Index_List,Constituents_List):
    random_name = ''.join([str(random.randint(0, 999)).zfill(3) for _ in range(2)])
    outFileName1="./static/backtest-file/output/"+random_name+"_index_value_file.csv"
    outFileName2="./static/backtest-file/output/"+random_name+"_constituents_file.csv"
    with open(outFileName1, 'w', newline='') as csvfile:
        writer1 = csv.writer(csvfile)
        writer1.writerow(["S.No","Date","Index Value PR","Index Value TR","Index Value NTR"])
        writer1.writerows(Index_List)
    with open(outFileName2, 'w', newline='') as csvfile:
        writer2 = csv.writer(csvfile)
        writer2.writerow(["S.No","Date","Index Value PR","Market CAP PR","Divisor PR","Index Value TR","Market CAP TR","Divisor TR","Index Value NTR","Market CAP NTR","Divisor NTR","ISIN","Currency","Country","TAX","Share PR","Share TR","Share NTR","Local Price","Index PRICE","MCAP PR","MCAP TR","MCAP NTR","Currency Price","Price Date","Weight PR","Weight TR","Weight NTR","Dividend","Special Dividend","Split","Spin"])
        writer2.writerows(Constituents_List)
    file_names = {'index_value_file':outFileName1,'constituents_file':outFileName2}
    return file_names

def Adjust_Dividend(divList,isinRow,Tax_Rate,D_ISIN_Currency,Ex_Rate,date,Latest_Price):
    isin = isinRow[1]
    country = isinRow[5]
    countryTax = Tax_Rate[country]/100
    toCurrency = D_ISIN_Currency[isin];
    aFactor_PR,aFactor_TR,aFactor_NTR = 1,1,1
    Dividend = ''
    sDividend = ''
    amount_PR=0
    amount_TR=0
    amount_NTR=0
    for row in divList:
        amount = row[1]
        amount_Tax = amount*(1-countryTax) 
        fromCurrency = row[3]
        divCode=row[4]
        if divCode in ('11','134'):
            sDividend += str(amount) + fromCurrency
            amount_PR  += amount*exRate
        else:
            Dividend += str(amount) + fromCurrency
        exRate = Get_Ex_Rate(fromCurrency,toCurrency,Ex_Rate,date)
        amount_TR  += amount*exRate
        amount_NTR += amount_Tax*exRate

    aFactor_PR =  (1 - (amount_PR/Latest_Price[isin][0]))
    aFactor_TR =  (1 - (amount_TR/Latest_Price[isin][0]))
    aFactor_NTR = (1 - (amount_NTR/Latest_Price[isin][0]))
    '''if aFactor_TR !=1:
        print("Dividend on "+str(date))
        print(isin)
        print(Latest_Price[isin][0])
        print(Dividend)
        print(sDividend)
        print(Latest_Price[isin][1])
        print(amount_TR)
        print(aFactor_TR)'''
        
    return aFactor_PR,aFactor_TR,aFactor_NTR,Dividend,sDividend

def Adjust_Spin(divList,isinRow,Tax_Rate,D_ISIN_Currency,Ex_Rate,date,Latest_Price):
    isin = isinRow[1]
    country = isinRow[5]
    countryTax = Tax_Rate[country]/100
    toCurrency = D_ISIN_Currency[isin];
    aFactor_PR,aFactor_TR,aFactor_NTR = 1,1,1
    Spin = 0
    for row in divList:
        amount = row[1]
        fromCurrency = row[3]       
        Spin = amount        
        exRate = Get_Ex_Rate(fromCurrency,toCurrency,Ex_Rate,date)
        amount_Tax = amount*(1-countryTax)
                 
        amount_PR  = amount*exRate
        amount_TR  = amount*exRate
        amount_NTR  = amount_Tax*exRate

        aFactor_PR =  aFactor_PR*(1 - (amount_PR/Latest_Price[isin][0]))
        aFactor_TR =  aFactor_TR*(1 - (amount_TR/Latest_Price[isin][0]))
        aFactor_NTR =  aFactor_NTR*(1 - (amount_NTR/Latest_Price[isin][0]))
    '''if aFactor_TR !=1:
        print("Spin  on "+str(date))
        print(isin)
        print(Latest_Price[isin][0])
        print(Latest_Price[isin][1])
        print(Spin)
        print(amount_TR)
        print(aFactor_TR)'''
    return aFactor_PR,aFactor_TR,aFactor_NTR,Spin

def Adjust_Split(splitList):
    sFactor_PR,sFactor_TR,sFactor_NTR = 1,1,1
    for row in splitList:
        sFactor_PR =  1/row[2]
        sFactor_TR =  1/row[2]
        sFactor_NTR =  1/row[2]    
    return sFactor_PR,sFactor_TR,sFactor_NTR,row[2]        

def Adjust_CA(D_Index,D_CA,isin_Data_Row,date,Tax_Rate,D_ISIN_Currency,Ex_Rate,Latest_Price):   
    
    dFactorPR,dFactorTR,dFactorNTR,sdFactorPR,sdFactorTR,sdFactorNTR =1,1,1,1,1,1
    spinFactorPR,spinFactorTR,spinFactorNTR,splitFactorPR,splitFactorTR,splitFactorNTR = 1,1,1,1,1,1
    Dividend,sDividend,Spin,Split = 0,0,0,0
    var = isin_Data_Row[1]+'_'+date
    
    dFactorPR,dFactorTR,dFactorNTR = 1,1,1
    sFactorPR,sFactorTR,sFactorNTR = 1,1,1
    if var in D_CA["Dividend"]:
        div_list = D_CA["Dividend"][var]
        dFactorPR,dFactorTR,dFactorNTR,Dividend,sDividend = Adjust_Dividend(div_list,isin_Data_Row,Tax_Rate,D_ISIN_Currency,Ex_Rate,date,Latest_Price)
    '''if var in D_CA["SDividend"]:
        sdiv_list = D_CA["SDividend"][var]
        #print(sdiv_list)
        sdFactorPR,sdFactorTR,sdFactorNTR,sDividend = Adjust_Special_Dividend(sdiv_list,isin_Data_Row,Tax_Rate,D_ISIN_Currency,Ex_Rate,date,Latest_Price)
        #print("S Factor")
        #print(date)
        #print(sdFactorPR)'''
    if var in D_CA["Spin"]:
        spin_list = D_CA["Spin"][var]
        spinFactorPR,spinFactorTR,spinFactorNTR,Spin = Adjust_Spin(spin_list,isin_Data_Row,Tax_Rate,D_ISIN_Currency,Ex_Rate,date,Latest_Price)
        
    if var in D_CA["Split"]:
        split_list = D_CA["Split"][var]
        splitFactorPR,splitFactorTR,splitFactorNTR,Split = Adjust_Split(split_list)
        #print("Split Factor for " + str(date))
        #print(splitFactorPR)
    CA= {}
    '''if date =='09/28/16' and isin_Data_Row[1] =='JP3311400000':
        print(dFactorPR)
        print(sdFactorPR)
        print(spinFactorPR)
        print(splitFactorPR)'''
    CA["PriceFactor_PR"] = dFactorPR*spinFactorPR/splitFactorPR
    CA["PriceFactor_TR"] = dFactorTR*spinFactorTR/splitFactorTR
    CA["PriceFactor_NTR"] = dFactorNTR*spinFactorNTR/splitFactorNTR

    CA["ShareFactor_PR"] = splitFactorPR
    CA["ShareFactor_TR"] = splitFactorTR
    CA["ShareFactor_NTR"] = splitFactorNTR
        
    if D_Index["Adjustment"] =="SA":
        CA["ShareFactor_PR"] *= 1/spinFactorPR
        CA["ShareFactor_TR"] *= 1/spinFactorTR
        CA["ShareFactor_NTR"] *= 1/spinFactorNTR
        
    CA["Dividend"] = Dividend
    CA["sDividend"] = sDividend
    CA["Spin"] = Spin
    CA["Split"] = Split        
    return CA

def Delist(Clist,date,D_LastDate,E_Date):
    for row in Clist:
        if D_LastDate[row[1]] == date and date > E_Date:
            Clist.remove(row)
            
def Cal_Index_Open(D_Index,Clist,Latest_Price,Latest_Ex_Rate,date,Tax_Rate,D_ISIN_Currency,Ex_Rate,D_CA):
    Constituents_List = list()
    M_CAP_PR,M_CAP_TR,M_CAP_NTR = 0,0,0
    Dividend,sDividend,Spin,Split = 0,0,0,0
    Index_Value_PR,Index_Value_TR,Index_Value_NTR = D_Index["Index_Value_PR"],D_Index["Index_Value_TR"],D_Index["Index_Value_NTR"]
    for inputRow in Clist:
        CA ={}
        isin = inputRow[1]
        CA = Adjust_CA(D_Index,D_CA,inputRow,date,Tax_Rate,D_ISIN_Currency,Ex_Rate,Latest_Price)
        Adjusted_Price_PR  = Latest_Price[isin][0]*CA["PriceFactor_PR"]
        Adjusted_Price_TR  = Latest_Price[isin][0]*CA["PriceFactor_TR"]
        Adjusted_Price_NTR = Latest_Price[isin][0]*CA["PriceFactor_NTR"]
        
        shares_PR = inputRow[7]*CA["ShareFactor_PR"]
        shares_TR = inputRow[8]*CA["ShareFactor_TR"]
        shares_NTR = inputRow[9]*CA["ShareFactor_NTR"]
        '''if date=='11/01/16':
            print('Open MCap for:' +isin+":::"+str(inputRow[7]))'''
        inputRow[7] = shares_PR
        inputRow[8] = shares_TR
        inputRow[9] = shares_NTR
        inputRow[13] = shares_PR*Adjusted_Price_PR*Latest_Ex_Rate[isin]
        inputRow[14] = shares_TR*Adjusted_Price_TR*Latest_Ex_Rate[isin]
        inputRow[15] = shares_NTR*Adjusted_Price_NTR*Latest_Ex_Rate[isin]
       
        M_CAP_PR  += shares_PR*Adjusted_Price_PR*Latest_Ex_Rate[isin]
        M_CAP_TR  += shares_TR*Adjusted_Price_TR*Latest_Ex_Rate[isin]
        M_CAP_NTR += shares_NTR*Adjusted_Price_NTR*Latest_Ex_Rate[isin]
        
        inputRow[16] = CA["Dividend"]
        inputRow[17] = CA["sDividend"]
        inputRow[18] = CA["Split"]
        inputRow[19] = CA["Spin"]
        
    D_Index["M_Cap_PR"]  = round(M_CAP_PR,13)
    D_Index["M_Cap_TR"]  = round(M_CAP_TR,13)
    D_Index["M_Cap_NTR"] = round(M_CAP_NTR,13)
    
    Divisor_PR  = round(M_CAP_PR,13)/Index_Value_PR
    Divisor_TR  = round(M_CAP_TR,13)/Index_Value_TR
    Divisor_NTR = round(M_CAP_NTR,13)/Index_Value_NTR

    #print(Latest_Price)
    #print('Divisor for '+date +' id :'+str(Divisor_PR))
    D_Index["Divisor_PR"]  = round(Divisor_PR,13)
    D_Index["Divisor_TR"]  = round(Divisor_TR,13)
    D_Index["Divisor_NTR"] = round(Divisor_NTR,13)

    '''if date=='11/01/16':
        print('Values at  Open :' +str(date))
        print(D_Index["M_Cap_PR"])
        print(D_Index["Index_Value_PR"])
        print(D_Index["Divisor_PR"])
        print('End Open')'''
    for row in Clist:
        row[10] = (row[13]*100)/round(M_CAP_PR,13)
        row[11] = (row[14]*100)/round(M_CAP_TR,13)
        row[12] = (row[15]*100)/round(M_CAP_NTR,13)
           
def Cal_Index_Close(D_Index,Clist,Latest_Price,Latest_Ex_Rate,date,Constituents_List_Final,period,Tax_Rate,D_ISIN_Currency,print_flag):
    Constituents_List = list()
    date=date.replace('/','-')
    #print("Cal_Index_Close")
    #print(date)
    #print("Cal_Index_Close")
    date = datetime.datetime.strptime(date,'%m-%d-%y').strftime('%d-%m-%Y')
    M_CAP_PR,M_CAP_TR,M_CAP_NTR = 0,0,0
    Index_Value_PR,Index_Value_TR,Index_Value_NTR = 0,0,0
    Divisor_PR = D_Index["Divisor_PR"]
    Divisor_TR = D_Index["Divisor_TR"]
    Divisor_NTR = D_Index["Divisor_NTR"]
    
    for row in Clist:
        isin = row[1]
        #if print_flag==1:
        #   Fill_Constituents_List(D_Index,Constituents_List,row,period,date,D_ISIN_Currency,Tax_Rate,Latest_Price,Latest_Ex_Rate)
        M_CAP_PR += row[7]*Latest_Price[isin][0]*Latest_Ex_Rate[isin]
        M_CAP_TR += row[8]*Latest_Price[isin][0]*Latest_Ex_Rate[isin]
        M_CAP_NTR += row[9]*Latest_Price[isin][0]*Latest_Ex_Rate[isin]
        row[13] = row[7]*Latest_Price[isin][0]*Latest_Ex_Rate[isin]
        row[14] = row[8]*Latest_Price[isin][0]*Latest_Ex_Rate[isin]
        row[15] = row[9]*Latest_Price[isin][0]*Latest_Ex_Rate[isin]
        '''if date=='31-10-2016':
            print('Close MCap for:' +isin+":::"+str(row[7]))'''
    Index_Value_PR  = round(M_CAP_PR,13)/Divisor_PR
    Index_Value_TR  = round(M_CAP_PR,13)/Divisor_TR
    Index_Value_NTR = round(M_CAP_PR,13)/Divisor_NTR
    
    D_Index["M_Cap_PR"]  = round(M_CAP_PR,13)
    D_Index["M_Cap_TR"]  = round(M_CAP_TR,13)
    D_Index["M_Cap_NTR"] = round(M_CAP_NTR,13)

    D_Index["Index_Value_PR"]  = round(Index_Value_PR,13)
    D_Index["Index_Value_TR"]  = round(Index_Value_TR,13)
    D_Index["Index_Value_NTR"] = round(Index_Value_NTR,13)

    '''if date=='31-10-2016' or date=='01-11-2016':
        print('Values at  Close :' +str(date))
        print(D_Index["M_Cap_PR"])
        print(D_Index["Index_Value_PR"])
        print(D_Index["Divisor_PR"])
        print('End Close')'''        
        
    for row in Clist:
        row[10] = (row[13]*100)/round(M_CAP_PR,13)
        row[11] = (row[14]*100)/round(M_CAP_TR,13)
        row[12] = (row[15]*100)/round(M_CAP_NTR,13)
        if print_flag==1:
            Fill_Constituents_List(D_Index,Constituents_List,row,period,date,D_ISIN_Currency,Tax_Rate,Latest_Price,Latest_Ex_Rate)
    '''for row in Constituents_List:
        row[2] = Index_Value_PR
        row[3] = round(M_CAP_PR,13)
        row[4] = Divisor_PR
        row[5] = Index_Value_TR
        row[6] = round(M_CAP_TR,13)
        row[7] = Divisor_TR
        row[8] = Index_Value_NTR
        row[9] = round(M_CAP_NTR,13)
        row[10] = Divisor_NTR'''
    Constituents_List_Final.extend(Constituents_List)
    
def Cal_Shares(D_Index,list,Latest_Price,Latest_Ex_Rate,date,Constituents_List,period,Tax_Rate,D_ISIN_Currency,print_flag,j):
    M_Cap_PR = D_Index["M_Cap_PR"]
    M_Cap_TR = D_Index["M_Cap_TR"]
    M_Cap_NTR = D_Index["M_Cap_NTR"]

    '''print("Cal_Shares")
    print(date)
    print(period)
    print(M_Cap_PR)
    print(M_Cap_TR)
    print(M_Cap_NTR)
    print(Latest_Price)
    print("Cal_Shares")'''
    
    date=date.replace('/','-')
    #print(date)
    #print("Cal_Shares")
    #print(date)
    date = datetime.datetime.strptime(date,'%m-%d-%y').strftime('%d-%m-%Y')
    ISIN_Shares = {}
    for inputRow in list:
        weight = float(inputRow[2][0:-1])
        isin = inputRow[1]
        shares_PR = (weight*M_Cap_PR)/(100*Latest_Price[isin][0]*Latest_Ex_Rate[isin])
        shares_TR = (weight*M_Cap_TR)/(100*Latest_Price[isin][0]*Latest_Ex_Rate[isin])
        shares_NTR = (weight*M_Cap_NTR)/(100*Latest_Price[isin][0]*Latest_Ex_Rate[isin])
        '''Shares(7,8,9)'''
        inputRow.append(shares_PR)
        inputRow.append(shares_TR)
        inputRow.append(shares_NTR)
        '''Weights(10,11,12)'''
        inputRow.append(weight)
        inputRow.append(weight)
        inputRow.append(weight)
        '''MCap(13,14,15)'''
        inputRow.append(shares_PR*Latest_Price[isin][0]*Latest_Ex_Rate[isin])
        inputRow.append(shares_TR*Latest_Price[isin][0]*Latest_Ex_Rate[isin])
        inputRow.append(shares_NTR*Latest_Price[isin][0]*Latest_Ex_Rate[isin])
        '''CA(16,17,18)'''
        inputRow.append('')
        inputRow.append('')
        inputRow.append('')
        inputRow.append('')
        if print_flag==1 and j==0:
            Fill_Constituents_List(D_Index,Constituents_List,inputRow,period,date,D_ISIN_Currency,Tax_Rate,Latest_Price,Latest_Ex_Rate)

def Fill_Constituents_List(D_Index,Constituents_List,row,period,date,D_ISIN_Currency,Tax_Rate,Latest_Price,Latest_Ex_Rate):
    Out_Row = [0]*32
    Out_Row[0] = period
    Out_Row[1] = date
    
    Out_Row[2] = D_Index["Index_Value_PR"]
    Out_Row[3] = D_Index["M_Cap_PR"]
    Out_Row[4] = D_Index["Divisor_PR"]
    Out_Row[5] = D_Index["Index_Value_TR"]
    Out_Row[6] = D_Index["M_Cap_TR"]
    Out_Row[7] = D_Index["Divisor_TR"]
    Out_Row[8] = D_Index["Index_Value_NTR"]
    Out_Row[9] = D_Index["M_Cap_NTR"]
    Out_Row[10] = D_Index["Divisor_NTR"]
    '''ISIN'''
    Out_Row[11] = row[1]
    '''Currency'''
    Out_Row[12] = D_ISIN_Currency[row[1]]
    '''Country'''
    Out_Row[13] = row[5]
    '''Tax'''
    Out_Row[14] = Tax_Rate[row[5]]
    '''Shares'''
    Out_Row[15] = row[7]
    Out_Row[16] = row[8]
    Out_Row[17] = row[9]

    '''Local Price'''
    Out_Row[18] = Latest_Price[row[1]][0]
    '''Index Level Price'''
    Out_Row[19] = Latest_Price[row[1]][0]*Latest_Ex_Rate[row[1]]
    #MCap
    Out_Row[20] = row[13]
    Out_Row[21] = row[14]
    Out_Row[22] = row[15]

    '''Ex Rate'''
    Out_Row[23] = Latest_Ex_Rate[row[1]]
    '''Price Date'''
    Out_Row[24] = Latest_Price[row[1]][1]
    #Weights
    Out_Row[25] = row[10]
    Out_Row[26] = row[11]
    Out_Row[27] = row[12]
    #CA
    Out_Row[28] = row[16]   
    Out_Row[29] = row[17]
    Out_Row[30] = row[18]
    Out_Row[31] = row[19]
    
    Constituents_List.append(Out_Row)
      

def Fill_Index_Report_Data(D_Index,Index_List,period,S_Date):
   row = []
   row.append(period)
   row.append(str(S_Date))
   row.append(D_Index["Index_Value_PR"])
   row.append(D_Index["Index_Value_TR"])
   row.append(D_Index["Index_Value_NTR"])                
   Index_List.append(row)
    
def Set_Latest_Price(list,D_Price,Latest_Price,date):
    for row in list:
        var1 = row[1]+'_'+date
        if var1 in D_Price:            
            price = D_Price[var1]
            Row = []
            Row.append(price)
            Row.append(date)
            Latest_Price[row[1]] = Row

def Get_Price(ISIN,D_Price,date,Latest_Price):
    var1 = ISIN+'_'+date
    if var1 in D_Price:            
        price = D_Price[var1]
        return price
    else:
        return Latest_Price[ISIN][0]
        
def Get_Ex_Rate(fromCurrency,toCurrency,Ex_Rate,date):
    var1 = fromCurrency +'_'+date
    if var1 in Ex_Rate:
        fromRate = (Ex_Rate[var1])
        if toCurrency =="USD":
            toRate = 1
        else:
            toRate = (Ex_Rate[toCurrency+'_'+date])
        ex_Rate = toRate/fromRate
        return ex_Rate
    else:
        return 1
    
def Set_Latest_Ex_Rate(Index_Currency,list,Ex_Rate,Latest_Ex_Rate,date,D_ISIN_Currency):
    for row in list:
        fromCurrency = D_ISIN_Currency[row[1]]
        var2 = fromCurrency +'_'+date
        if var2 in Ex_Rate:
            fromRate = (Ex_Rate[fromCurrency+'_'+date])
            if Index_Currency =="USD":
                toRate = 1
            else:
                toRate = (Ex_Rate[Index_Currency+'_'+date])
            ex_Rate = toRate/fromRate
            Latest_Ex_Rate[row[1]] = ex_Rate
        else:
            if Index_Currency =="USD" and fromCurrency=="USD":
                Latest_Ex_Rate[row[1]] = 1

