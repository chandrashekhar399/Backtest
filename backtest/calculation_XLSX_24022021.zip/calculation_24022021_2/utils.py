import csv
from django.db import connection
import datetime
import pyodbc
import random
import calculation.Functions_db as func_data
import calculation.Calculate as c
from itertools import chain
import glob
import os

#======Database Connections===========================#
#conn1 = pyodbc.connect('DRIVER={ODBC Driver 11 for SQL Server};SERVER=65.0.33.214;DATABASE=FDS_Datafeeds;UID=sa;PWD=Indxx@1234')
#cur = conn1.cursor()

def Load_CSV(file_Name,tax_file_path):  
    #final_data = cal.Validate_Read_CSV(file_Name,IDentifier)  
    cal = c.Calculation()
    with cal:
        final_data = cal.Load_CSV(file_Name,tax_file_path)       
    return final_data

def Validate_Read_CSV(file_Name, IDentifier, tax_file_path):
    print(tax_file_path)  
    #final_data = cal.Validate_Read_CSV(file_Name,IDentifier)  
    cal = c.Calculation()
    with cal:
        final_data = cal.Validate_Read_CSV(file_Name,IDentifier,tax_file_path)       
    return final_data

def Cal_Index(D_Index,D_Data,D_ISIN,D_Date,quote_data,last_Period,ISIN_LIST,Tax_Rate):    
    #files = cal.Cal_Index(D_Index,D_Data,D_ISIN,D_Date,quote_data,last_Period,cur)
    files ={}
    cal = c.Calculation()
    with cal:
        files = cal.Cal_Index(D_Index,D_Data,D_ISIN,D_Date,quote_data,last_Period,ISIN_LIST,Tax_Rate)
    return files


def handle_uploaded_file(file, confirmbox):
    if file:
        #print('file is there')
        #print(file)
        random_id = ''.join([str(random.randint(0, 999)).zfill(3) for _ in range(2)])
        file_name = random_id+'-'+file.name
        if confirmbox == '':     
            with open('./static/backtest-file/input/'+file_name, 'wb+') as destination:
                for chunk in file.chunks():
                    destination.write(chunk)
        return file_name


def remove_percent_symbole(weight):
    weight = list(weight)
    weight =  weight[:-1]
    weight = ''.join([str(elem) for elem in weight])
    return weight

def Rerun_Dbdata(D_Index, start_date, end_date, Period, get_composition):
    D_Data ={}
    D_ISIN ={}
    D_Date ={}
    data = []
    D_RIC_ISIN = {}
    quote_data = {}
    start_date = start_date.strftime('%m/%d/%Y').replace('/','-')
    format_str = '%Y-%m-%d'
    date1 = datetime.datetime.strptime(end_date, format_str).date()- datetime.timedelta(days=0)
    print(date1) 
    end_date = date1.strftime('%m-%d-%Y').replace('/','-')
    
    st_date = str(Period["Last"])+"_START"
    en_date = str(Period["Last"])+"_END"
    D_Date[st_date] = start_date
    D_Date[en_date] = end_date
    comp_isin =[]
    outer_comp_list =[]
    for data_composition in get_composition:
        comp_data = []
        weights = data_composition.weights
        weights = str(weights)+'%'
        comp_data.append(Period["Last"])
        comp_data.append(data_composition.isin)
        comp_data.append(weights)
        comp_data.append(start_date)
        comp_data.append(end_date)
        comp_data.append(data_composition.country)
        comp_data.append(data_composition.ric)
        outer_comp_list.append(comp_data)
        comp_isin.append(data_composition.isin)
        D_RIC_ISIN[data_composition.ric] = data_composition.isin
        quote_data[data_composition.isin] = data_composition.quote_id
    data.append(outer_comp_list)
    D_Data[str(Period["Last"])] = outer_comp_list
    D_ISIN [str(Period["Last"])] = comp_isin
    #save_file = Cal_Index(D_Index, D_Data, D_ISIN, D_Date, D_RIC_ISIN, period)
    #return save_file
    files ={}
    cal = c.Calculation()
    with cal:
        files = cal.Cal_Index(D_Index,D_Data,D_ISIN,D_Date,quote_data,Period,comp_isin)
    return files

def DateTime(current_time):
    date_time = datetime.datetime.strptime(current_time, "%m-%d-%Y")
    cr_date = date_time.strftime("%Y-%m-%d %H:%M:%S.%f")
    return cr_date