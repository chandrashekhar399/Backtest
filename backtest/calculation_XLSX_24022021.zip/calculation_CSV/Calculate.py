import calculation.Functions_db as f
import pyodbc 
import calculation.Functions_Calculate as f_c
from itertools import chain
import datetime
import csv 

class Calculation:

    def __init__(self):
        self.conn = None

    def __enter__(self):
        self.conn = pyodbc.connect('DRIVER={ODBC Driver 11 for SQL Server};SERVER=65.0.33.214;DATABASE=FDS_Datafeeds;UID=sa;PWD=Indxx@1234')
        self.conn.autocommit = True
        self.cursor = self.conn.cursor()
        
    def __exit__(self, *args):
        if self.conn:
            #self.cursor.commit()
            self.cursor.close()
            self.conn.close()
            self.conn = None
            
    def Load_CSV(self,file_Name):
        d1 = {}
        d2 = {}
        D_Data= {}
        D_Date = {}
        D_ISIN = {}
        D_ISIN_RIC = {}
        ISIN_LIST = []
        quote_data = {}
        last_Period = 1
        First_Period = 1
        errorMessage = ""
        warningMessage = ""
        i = 0
        with open(file_Name,'r') as csvfile:
            csvreader = csv.reader(csvfile)
            for line in csvreader:
                line[3] = line[3].replace('/','-')
                line[4] = line[4].replace('/','-')
                if i!=0 :
                    last_Period = line[0]
                    f.Load_Data(line,d1,d2,D_Data,D_Date,D_ISIN,ISIN_LIST)
                i += 1
        Period = {}
        Period["Last"] = last_Period
        Period["First"] = First_Period
        final_data = {'error': '', 'warning': '','D_Data':D_Data, 'D_Date': D_Date, 'D_ISIN':D_ISIN, 'Period':Period, 'D_ISIN_RIC':D_ISIN_RIC, 'quote_data': quote_data,'ISIN_LIST':ISIN_LIST}              
        return final_data
    
    def Validate_Read_CSV(self,file_Name,Identifier):
        d1 = {}
        d2 = {}
        D_Data= {}
        D_Date = {}
        D_ISIN = {}
        D_ISIN_RIC = {}
        quote_data = {}
        ISIN_LIST = []
        last_Period = 1
        First_Period = 1
        errorMessage = ""
        warningMessage = ""
        i = 0
        with open(file_Name,'r') as csvfile:
            csvreader = csv.reader(csvfile)
            for line in csvreader:
                line[3] = line[3].replace('/','-')
                line[4] = line[4].replace('/','-')
                if i==0 :
                    if bool(f.Validate_Columns_Order(line)):
                        errorMessage = "Please check your portfolio.Columns should be in order (Period, ISIN, Weights, Start date, End date, Country, RIC)."
                        return {'error': errorMessage, 'warning':''}                        
                else:
                    strMessage = f.Validate_Data(line,D_Date,last_Period)
                    if strMessage not in (None, ""):
                        return {'error': strMessage, 'warning':''}                        
                    else:
                        last_Period = line[0]                        
                        f.Load_Data(line,d1,d2,D_Data,D_Date,D_ISIN,ISIN_LIST)
                i += 1
            '''Check for Total sum of weights'''                        
            for key in d1:
                if d1[key]>100.44 or d1[key]<99.50:
                    errorMessage += "Total weight of period " + key +" is " + str(d1[key])+"."
            '''Check for Delisted Securities'''            
            for key in D_ISIN:
                isins=D_ISIN[key]
                startDate = D_Date[key+'_'+'START']
                delistedISINs = f.Delisting_Check(self.cursor,isins,startDate, Identifier)
                if delistedISINs not in (None, ""):
                    errorMessage += "Securities " + delistedISINs +" of period - "+key+" is not trading start at the start of the period . "
            '''Check for Warning '''
            for key in d2:
                 if d2[key]>45:
                     warningMessage +="Sum of weights of securities for period " + key +" with greater than 5% weight is  " + str(d2[key])+"."
            yesterday = datetime.datetime.now()- datetime.timedelta(days=1)
            yesterday_date = yesterday.strftime("%x")
            
            format_str = '%m-%d-%Y'
            Last_Period_End_Date = datetime.datetime.strptime(D_Date[last_Period+'_END'], format_str).date()
            
            if yesterday_date == Last_Period_End_Date.strftime("%x"):
                for line in D_Data[last_Period]:
                    if line[6] in (None, "") :
                        errorMessage = "Please check your portfolio.Few Securities in last period does not have proper RIC."
                        return {'error': errorMessage, 'warning':''}                       
                    else:                        
                        D_ISIN_RIC[line[1]]=line[6]
                if D_ISIN_RIC:
                    validate_ric = f.check_ric(D_ISIN_RIC)
                    #print(validate_ric)
                    if validate_ric['status']== False:
                        errorMessage += validate_ric['message']
                    else:                    
                        quote_data = validate_ric['isin_quote_data']
            if errorMessage not in (None, ""):
                errorMessage = "Please check your portfolio."+errorMessage
        Period = {}
        Period["Last"] = last_Period
        Period["First"] = First_Period
        final_data = {'error': errorMessage, 'warning': warningMessage, 'D_Data':D_Data, 'D_Date': D_Date, 'D_ISIN':D_ISIN, 'Period':Period, 'D_ISIN_RIC':D_ISIN_RIC, 'quote_data': quote_data,'ISIN_LIST':ISIN_LIST}              
        return final_data

    def Cal_Index(self,D_Index,D_Data,D_ISIN,D_Date,quote_data,Period,ISIN_LIST):
        print(D_Index)
        print(D_Data)
        print(D_ISIN)
        print(D_Date)
        print(quote_data)
        print(Period["Last"])
        print(ISIN_LIST)

        Index_List = list()
        First_Period = Period["First"]
        last_Period = Period["Last"]
        #print('Cal Starts'+str(datetime.datetime.now()))
        Constituents_List = list()
        D_Index["M_Cap_PR"],D_Index["M_Cap_TR"],D_Index["M_Cap_NTR"]=D_Index["MV"],D_Index["MV"],D_Index["MV"]
        D_Index["Index_Value_PR"], D_Index["Index_Value_TR"],D_Index["Index_Value_NTR"]= D_Index["IV"],D_Index["IV"],D_Index["IV"]
        Divisor = D_Index["MV"]/D_Index["IV"]
        D_Index["Divisor_PR"], D_Index["Divisor_TR"],D_Index["Divisor_NTR"]=Divisor,Divisor,Divisor
        j=0
        #for period in D_Data:
        Tax_Rate = f.Get_TAX()
        Index_Currency = D_Index["Currency"]
        format_str = '%m-%d-%Y'
        S_Date = datetime.datetime.strptime(D_Date[str(First_Period)+"_START"], format_str).date()- datetime.timedelta(days=0)
        E_Date = datetime.datetime.strptime(D_Date[str(last_Period)+"_END"], format_str).date()- datetime.timedelta(days=0)
        
        if S_Date.weekday()==5:
            S_Date = S_Date - datetime.timedelta(days=1)
        elif S_Date.weekday()==6:
            S_Date = S_Date - datetime.timedelta(days=2)
                
        S_Date_Minus_Five = S_Date - datetime.timedelta(days=5)        
        #print(S_Date_Minus_Five)
        #print(S_Date)
        #print(E_Date)
        print('Get Data Starts'+str(datetime.datetime.now()))
        D_Price,D_LastDate,currency_list,D_ISIN_Currency = f.Get_PRICE(self.cursor,ISIN_LIST,S_Date_Minus_Five.strftime("%x"),E_Date.strftime("%x"),D_Index["Identifier"])
        currency_list.append(Index_Currency)
        Ex_Rate = f.Get_Currency(self.cursor,currency_list,S_Date_Minus_Five.strftime("%x"),E_Date.strftime("%x"))
        D_CA = f.Get_CA(self.cursor,ISIN_LIST,S_Date.strftime("%x"),E_Date.strftime("%x"),D_Index["Identifier"])
        print('Get Data Ends'+str(datetime.datetime.now()))
        for period in D_Data:            
            S_Date = datetime.datetime.strptime(D_Date[period+"_START"], format_str).date()- datetime.timedelta(days=0)
            
            if S_Date.weekday()==5:
                S_Date = S_Date - datetime.timedelta(days=1)
            elif S_Date.weekday()==6:
                S_Date = S_Date - datetime.timedelta(days=2)
                
            S_Date_Minus_Five = datetime.datetime.strptime(D_Date[period+"_START"], format_str).date()- datetime.timedelta(days=5)
            E_Date = datetime.datetime.strptime(D_Date[period+"_END"], format_str).date()- datetime.timedelta(days=0)
            
            i=0
            if period ==last_Period:
                f.Set_TR_Price(D_Date,quote_data,last_Period,D_Price)
            Latest_Price={}
            Latest_Ex_Rate={}

            while S_Date_Minus_Five <= E_Date:
                f_c.Set_Latest_Ex_Rate(Index_Currency,D_Data[period],Ex_Rate,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),D_ISIN_Currency)
                f_c.Set_Latest_Price(D_Data[period],D_Price,Latest_Price,S_Date_Minus_Five.strftime("%x"))
                if S_Date_Minus_Five>=S_Date:
                    print_flag = f_c.GetFlag(D_Index["DCFO"],S_Date_Minus_Five.strftime("%x"),D_Date[period+'_END'])
                    if i==0:                    
                        f_c.Cal_Shares(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Constituents_List,period,Tax_Rate,D_ISIN_Currency,print_flag,j)
                    else:
                        M_Cap = f_c.Cal_Index_Close(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Constituents_List,period,Tax_Rate,D_ISIN_Currency,print_flag)
                    f_c.Fill_Index_Report_Data(D_Index,Index_List,period,S_Date_Minus_Five)
                    i += 1
                    j += 1                    
                if S_Date_Minus_Five.weekday()==4:
                    S_Date_Minus_Five = S_Date_Minus_Five + datetime.timedelta(days=3)
                else:
                    S_Date_Minus_Five = S_Date_Minus_Five + datetime.timedelta(days=1)

                if S_Date_Minus_Five>S_Date and i!=0 and S_Date_Minus_Five <= E_Date:
                    f_c.Delist(D_Data[period],S_Date_Minus_Five.strftime("%x"),D_LastDate,E_Date.strftime("%x"))
                    f_c.Cal_Index_Open(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Tax_Rate,D_ISIN_Currency,Ex_Rate,D_CA)
            
        print('Cal Ends'+str(datetime.datetime.now()))
        files = f_c.Print_Reports(Index_List,Constituents_List)
        return files
